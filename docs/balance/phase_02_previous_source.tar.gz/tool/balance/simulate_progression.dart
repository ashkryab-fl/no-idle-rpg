import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:idle_companion/content/animations/animation_resources.dart';
import 'package:idle_companion/content/animations/enemies/procedural_timelines.dart';
import 'package:idle_companion/core/animation/animation_clip.dart';
import 'package:idle_companion/core/animation/attack_playback.dart';
import 'package:idle_companion/core/animation/ids.dart';
import 'package:idle_companion/core/balance/game_balance.dart';
import 'package:idle_companion/core/balance/progression_balance.dart';
import 'package:idle_companion/core/numbers/amount.dart';
import 'package:idle_companion/domain/character/character.dart';
import 'package:idle_companion/domain/equipment/equipment.dart';
import 'package:idle_companion/domain/progression/infinite_upgrade.dart';
import 'package:idle_companion/game/systems/combat_system.dart';
import 'package:idle_companion/game/systems/drop_system.dart';
import 'package:idle_companion/game/systems/enemy_spawner.dart';
import 'package:idle_companion/game/systems/progression_system.dart';

export 'package:idle_companion/game/systems/combat_system.dart'
    show DamageEvent;

enum InvestmentStrategy { balanced, noPurchases, weaponOnly, armorOnly }

/// Discrete attacks and phase boundaries, using the game's stats and catalogs.
/// Productive time excludes rest/offline time. Purchases occur between encounters.
/// Pending events survive checkpoints: an unconfirmed kill earns no reward.
class ProgressionSimulation {
  ProgressionSimulation({
    int seed = 1,
    Random? random,
    CharacterProgress? character,
    List<EnemyDefinition>? definitions,
    this.goldCostGrowth = ProgressionBalance.equipmentCostGrowth,
    this.bookCostGrowth = ProgressionBalance.bookUpgradeCostGrowth,
    this.upgradeInterval = 3600,
    this.strategy = InvestmentStrategy.balanced,
    this.onEncounter,
    this.onRecovery,
  }) : random = random ?? Random(seed),
       hero = character ?? CharacterProgress() {
    spawner = EnemySpawner(this.random, definitions: definitions);
    combat = CombatSystem(
      this.random,
      heroPlayback: AttackPlayback(resources.clip(const ClipId('hero.attack'))),
      enemyPlayback: AttackPlayback(ProceduralEnemyTimelines.attack),
    );
    drops = DropSystem(this.random);
    stats = CharacterStats.calculate(hero);
    hp = stats.maxHp;
    _recovered('initial', Amount.zero);
    _schedule(0, _travel);
  }

  final double goldCostGrowth, bookCostGrowth, upgradeInterval;
  final InvestmentStrategy strategy;
  final Random random;
  final CharacterProgress hero;
  final void Function(Map<String, Object?> trace)? onEncounter;
  final void Function(Map<String, Object?> event)? onRecovery;
  final progression = ProgressionSystem();
  final resources = defaultAnimationResources();
  late final EnemySpawner spawner;
  late final CombatSystem combat;
  late final DropSystem drops;
  late CombatStats stats;
  late Amount hp;
  int stage = 1, stageKills = 0, kills = 0, deaths = 0;
  int successfulPurchases = 0, hpPurchases = 0, respawnHeals = 0;
  Amount goldEarned = Amount.zero, booksEarned = Amount.zero;
  Amount purchaseHealing = Amount.zero;
  double elapsed = 0, _nextUpgrade = 0, _pendingAt = 0;
  void Function()? _pending;
  final _firstEntry = <int, double>{1: 0};
  final firstClearSeconds = <double>[];
  final killSeconds = <double>[];
  final normalSeconds = <double>[], bossSeconds = <double>[];
  final hpBeforeFractions = <double>[], hpAfterFractions = <double>[];
  final purchaseWaitSeconds = <double>[];
  final recentDeaths = <double>[];
  double _lastPurchase = 0;
  Enemy? enemy;
  bool _rewardPending = false;
  bool get rewardPending => _rewardPending;

  void _schedule(double at, void Function() work) {
    _pendingAt = at;
    _pending = work;
  }

  void runUntil(double deadline) {
    if (!deadline.isFinite || deadline < elapsed) {
      throw ArgumentError.value(deadline, 'deadline');
    }
    while (_pending != null && _pendingAt <= deadline) {
      elapsed = _pendingAt;
      final work = _pending!;
      _pending = null;
      work();
    }
    elapsed = deadline;
  }

  void _travel() {
    if (elapsed >= _nextUpgrade) {
      invest();
      _nextUpgrade = elapsed + upgradeInterval;
    }
    final travel =
        spawner.nextDistance() / GameBalance.movementSpeed +
        GameBalance.approachDuration;
    _schedule(elapsed + travel, _encounter);
  }

  void _encounter() {
    final foe = spawner.spawn(
      stage - 1,
      isBoss: stageKills + 1 == ProgressionBalance.enemiesPerStage,
    );
    enemy = foe;
    final start = elapsed, beforeHp = hp, maxHp = stats.maxHp;
    final encounterStage = stage, wave = stageKills + 1;
    final hits = <DamageEvent>[];
    final heroPeriod = 1 / stats.attackSpeed;
    final enemyPeriod = 1 / foe.stats.attackSpeed;
    double firstHit(AnimationClipDefinition clip, double period) =>
        clip.markers
            .firstWhere((m) => m.kind == AnimationMarkerKind.damage)
            .time *
        min(1, period / clip.duration);
    var nextHero = firstHit(
      resources.clip(const ClipId('hero.attack')),
      heroPeriod,
    );
    var nextEnemy = firstHit(
      foe.definition.animations.attack(resources),
      enemyPeriod,
    );
    _sample(hpBeforeFractions, hp.ratio(maxHp));

    void record(bool victory, double hitTime) {
      _sample(recentDeaths, victory ? 0 : 1);
      _sample(hpAfterFractions, hp.ratio(maxHp));
      onEncounter?.call({
        'stage': encounterStage,
        'wave': wave,
        'boss': foe.isBoss,
        'victory': victory,
        'combatSeconds': hitTime,
        'start': start,
        'confirmedAt': elapsed,
        'hpBeforeLog': beforeHp.toJson(),
        'hpAfterLog': hp.toJson(),
        'hits': [
          for (final hit in hits)
            {
              'hero': hit.fromHero,
              'critical': hit.critical,
              'amountLog': hit.amount.toJson(),
              'time': hit.timeWithinStep,
            },
        ],
      });
    }

    late void Function() scheduleHit;
    scheduleHit = () {
      final fromHero = nextHero <= nextEnemy + 1e-12;
      final hitTime = fromHero ? nextHero : nextEnemy;
      _schedule(start + hitTime, () {
        final hit = combat.calculate(
          fromHero ? stats : foe.stats,
          fromHero,
          timeWithinStep: hitTime,
        );
        if (onEncounter != null) hits.add(hit);
        if (fromHero) {
          foe.hp = foe.hp - hit.amount;
          nextHero += heroPeriod;
          if (foe.hp.isZero) {
            _rewardPending = true;
            _schedule(
              elapsed + foe.definition.animations.death(resources).duration,
              () {
                _rewardPending = false;
                final reward = drops.roll(foe);
                hero.gold = hero.gold + reward.gold;
                hero.books = hero.books + reward.books;
                goldEarned = goldEarned + reward.gold;
                booksEarned = booksEarned + reward.books;
                kills++;
                _sample(killSeconds, hitTime);
                _sample(foe.isBoss ? bossSeconds : normalSeconds, hitTime);
                stageKills++;
                if (stageKills == ProgressionBalance.enemiesPerStage) {
                  stage++;
                  stageKills = 0;
                  if (!_firstEntry.containsKey(stage)) {
                    firstClearSeconds.add(
                      elapsed - (_firstEntry[stage - 1] ?? start),
                    );
                    _firstEntry[stage] = elapsed;
                  }
                }
                record(true, hitTime);
                _schedule(elapsed + GameBalance.rewardDuration, () {
                  enemy = null;
                  _travel();
                });
              },
            );
            return;
          }
        } else {
          hp = hp - hit.amount;
          nextEnemy += enemyPeriod;
          if (hp.isZero) {
            deaths++;
            stage = max(1, stage - 1);
            stageKills = 0;
            record(false, hitTime);
            _schedule(
              elapsed +
                  resources.clip(const ClipId('hero.death')).duration +
                  GameBalance.respawnDuration,
              () {
                final before = hp;
                hp = stats.maxHp;
                _recovered('respawn', before);
                respawnHeals++;
                enemy = null;
                _travel();
              },
            );
            return;
          }
        }
        scheduleHit();
      });
    };
    scheduleHit();
  }

  /// Explicit between-encounter purchases; returns actual successful counts.
  void invest() {
    if (strategy == InvestmentStrategy.noPurchases) return;
    final oldMax = stats.maxHp;
    final oldHp = hp;
    final beforePurchases = successfulPurchases;
    final shares = switch (strategy) {
      InvestmentStrategy.weaponOnly => [1.0, 0.0, 0.0, 0.0],
      InvestmentStrategy.armorOnly => [0.0, 1.0, 0.0, 0.0],
      _ => [0.375, 0.375, 0.15, 0.10],
    };
    final gold = hero.gold, books = hero.books;
    const equipment = ['weapon', 'armor', 'helmet', 'amulet'];
    for (var i = 0; i < shares.length; i++) {
      if (shares[i] == 0) continue;
      for (final isEquipment in [true, false]) {
        final source = isEquipment
            ? EquipmentCatalog.items.firstWhere(
                (item) => item.id == equipment[i],
              )
            : UpgradeCatalog.character[i];
        final item = InfiniteUpgradeDefinition(
          id: source.id,
          name: source.name,
          stat: source.stat,
          baseCost: source.baseCost,
          costGrowth: isEquipment ? goldCostGrowth : bookCostGrowth,
          curve: source.curve,
          valueGrowth: source.valueGrowth,
          softCapRate: source.softCapRate,
          bonusPerLevel: source.bonusPerLevel,
        );
        final levels = isEquipment ? hero.equipment : hero.upgrades;
        final count = item.affordable(
          levels[item.id] ?? 0,
          (isEquipment ? gold : books).scale(shares[i]),
        );
        final bought = progression.upgrade(
          hero,
          item,
          equipment: isEquipment,
          count: count,
        );
        if (bought > 0) {
          successfulPurchases++;
          if (item.stat == CharacterStat.maxHp) hpPurchases++;
        }
      }
    }
    stats = CharacterStats.calculate(hero);
    if (!hp.isZero) {
      final restored = hp + (stats.maxHp - oldMax);
      hp = restored > stats.maxHp ? stats.maxHp : restored;
      purchaseHealing = purchaseHealing + (hp - oldHp);
      if (hp > oldHp) _recovered('hpPurchase', oldHp);
    }
    if (successfulPurchases > beforePurchases) {
      _sample(purchaseWaitSeconds, elapsed - _lastPurchase);
      _lastPurchase = elapsed;
    }
  }

  void _recovered(String reason, Amount before) => onRecovery?.call({
    'reason': reason,
    'productiveSeconds': elapsed,
    'beforeLog': before.toJson(),
    'afterLog': hp.toJson(),
    'maxHpLog': stats.maxHp.toJson(),
  });

  static void _sample(List<double> values, double value) {
    values.add(value);
    if (values.length > 200) values.removeAt(0);
  }

  static double percentile(Iterable<double> values, double p) {
    final sorted = values.toList()..sort();
    if (sorted.isEmpty) return 0;
    final index = (sorted.length - 1) * p;
    final low = index.floor(), high = index.ceil();
    return sorted[low] + (sorted[high] - sorted[low]) * (index - low);
  }

  static double median(Iterable<double> values) => percentile(values, .5);

  Map<String, Object?> snapshot(int day) => {
    'day': day,
    'productiveSeconds': elapsed,
    'stage': stage,
    'wave': stageKills + 1,
    'highestStage': _firstEntry.keys.reduce(max),
    'kills': kills,
    'deaths': deaths,
    'deathsPer100RecentEncounters': recentDeaths.isEmpty
        ? 0.0
        : 100 * recentDeaths.reduce((a, b) => a + b) / recentDeaths.length,
    'medianRecentStageSeconds': median(
      firstClearSeconds.skip(max(0, firstClearSeconds.length - 20)),
    ),
    'medianRecentKillSeconds': median(killSeconds),
    'normalTtkP50': median(normalSeconds),
    'normalTtkP90': percentile(normalSeconds, .9),
    'bossTtkP50': median(bossSeconds),
    'bossTtkP90': percentile(bossSeconds, .9),
    'hpBeforeFractionP50': median(hpBeforeFractions),
    'hpAfterFractionP50': median(hpAfterFractions),
    'hpPurchaseHealingLog': purchaseHealing.toJson(),
    'successfulPurchases': successfulPurchases,
    'hpPurchases': hpPurchases,
    'respawnHeals': respawnHeals,
    'purchaseWaitP50': median(purchaseWaitSeconds),
    'purchaseWaitP90': percentile(purchaseWaitSeconds, .9),
    'goldEarnedLog': goldEarned.toJson(),
    'booksEarnedLog': booksEarned.toJson(),
    'goldRemainingLog': hero.gold.toJson(),
    'booksRemainingLog': hero.books.toJson(),
    'maxHpLog': stats.maxHp.toJson(),
    'currentHpLog': hp.toJson(),
    'damageLog': stats.damage.toJson(),
    'equipment': Map.of(hero.equipment),
    'upgrades': Map.of(hero.upgrades),
    'firstStageEntrySeconds': {
      for (final entry in _firstEntry.entries) '${entry.key}': entry.value,
    },
    'rewardPending': rewardPending,
    'weapon': hero.equipment['weapon'] ?? 0,
    'bookDamage': hero.upgrades['damage'] ?? 0,
  };
}

void main(List<String> args) {
  double option(String name, double fallback) {
    final index = args.indexOf(name);
    return index < 0 ? fallback : double.parse(args[index + 1]);
  }

  final hours = option('--hours-per-day', 7);
  final seeds = option('--seeds', 20).toInt();
  final days = option('--days', 30).toInt();
  final rows = <Map<String, Object?>>[];
  final checkpoints = [1, 7, days].where((day) => day <= days).toSet().toList()
    ..sort();
  for (var seed = 1; seed <= seeds; seed++) {
    final sim = ProgressionSimulation(
      seed: seed,
      goldCostGrowth: option(
        '--gold-cost-growth',
        ProgressionBalance.equipmentCostGrowth,
      ),
      bookCostGrowth: option(
        '--book-cost-growth',
        ProgressionBalance.bookUpgradeCostGrowth,
      ),
    );
    for (final day in checkpoints) {
      sim.runUntil(day * hours * 3600);
      rows.add({'seed': seed, ...sim.snapshot(day)});
    }
  }
  stdout.writeln(
    jsonEncode({
      'hoursPerDay': hours,
      'seeds': seeds,
      'strategy': 'hourly_balanced',
      'time': 'productive, no rest or restart',
      'rows': rows,
    }),
  );
}
