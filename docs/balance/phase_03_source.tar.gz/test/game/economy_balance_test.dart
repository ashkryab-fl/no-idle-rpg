import 'package:idle_companion/domain/character/character.dart';
import 'package:idle_companion/content/animations/enemies/procedural_timelines.dart';

import 'package:flutter_test/flutter_test.dart';
import 'package:idle_companion/domain/equipment/equipment.dart';
import 'package:idle_companion/game/systems/drop_system.dart';
import 'package:idle_companion/game/systems/enemy_spawner.dart';

EnemyDefinition definition() => EnemyDefinition(
  id: 'test',
  name: 'Test',
  baseHp: 48,
  baseDamage: 6,
  attackSpeed: .75,
  rewardGold: 12,
  animations: ProceduralEnemyTimelines.content,
);

void main() {
  test(
    'loot and upgrade math remains finite beyond ordinary double magnitudes',
    () {
      final enemy = EnemyFactory().create(definition(), 1000000);
      final reward = DropSystem.killReward(enemy);
      expect(reward.gold.log10, greaterThan(308));
      expect(reward.books.isZero, isTrue);
      expect(reward.gold.log10.isFinite, isTrue);
      final item = EquipmentCatalog.items.first;
      final price = item.batchCost(1000000, 1000000);
      expect(price.log10.isFinite, isTrue);
      expect(item.affordable(1000000, price), 1000000);
      expect(
        CharacterStats.calculate(
          CharacterProgress()..equipment['weapon'] = 1000000,
        ).damage.log10.isFinite,
        isTrue,
      );
    },
  );
}
